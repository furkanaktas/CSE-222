/**
 *
 * @author furkan
 */
public interface Interface {
    
    /**
     * This function force user to write appropriate shell.
     */
    public void managementShell();
    
}
